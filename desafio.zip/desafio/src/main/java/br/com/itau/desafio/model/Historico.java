package br.com.itau.desafio.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="TBL_DESAFIO_HISTORICOS")
public class Historico {
	
	@Column(name="IDHISTORICOS")
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idHistorico;
	
	@JsonIgnoreProperties("historicos")
	@ManyToOne
	private Colaborador colaborador;
		
	@JsonIgnoreProperties("historico")
	@ManyToOne
	private Departamento departamento;
	
	@Column(name="DATASOLICITACAO")
	@Temporal(TemporalType.DATE)
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="dd/MM/yyyy")
	private Date dataSolic;
		
	@Column(name="JUST", length=100)
	private String justificativa;
		
	@Column(name="COMANDOS", length=100)
	private String comandos;

	public int getIdHistorico() {
		return idHistorico;
	}

	public void setIdHistorico(int idHistorico) {
		this.idHistorico = idHistorico;
	}

	public Colaborador getColaborador() {
		return colaborador;
	}

	public void setColaborador(Colaborador colaborador) {
		this.colaborador = colaborador;
	}

	public Departamento getDepartamento() {
		return departamento;
	}

	public void setDepartamento(Departamento departamento) {
		this.departamento = departamento;
	}

	public Date getDataSolic() {
		return dataSolic;
	}

	public void setDataSolic(Date dataSolic) {
		this.dataSolic = dataSolic;
	}

	public String getJustificativa() {
		return justificativa;
	}

	public void setJustificativa(String justificativa) {
		this.justificativa = justificativa;
	}

	public String getComandos() {
		return comandos;
	}

	public void setComandos(String comandos) {
		this.comandos = comandos;
	}

	



}
