package br.com.itau.desafio.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="TBL_DESAFIO_COLABORADORES")
public class Colaborador {

	@Column(name="IdColab")
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idColab;
	
	@Column(name="RACF")
	private int racf;
	
	@Column(name="NOME", length=100)
	private String nomeColab;
	
	@JsonIgnoreProperties("colaboradores")
	@ManyToOne
	private Departamento departamento;
	
	@JsonIgnoreProperties("colaborador")
	@OneToMany(cascade=CascadeType.ALL , mappedBy="colaborador")
	private List<Historico> historicos;
		
	@Column(name="EMAIL", length=100)
	private String email;
	
	@Column(name="SENHA", length=15)
	private String senha;
	
	@Column(name="NUMEQUIPAMENTO")
	private int numEquip;
	
	@Column(name="DESCEQUIPAMENTO", length=100)
	private String descEquip;
	
	@Column(name="NUMCONECTREDE", length=100)
	private String numConectRede;
	
	@Column(name="FOTO", length=100)
	private String foto;

	public int getIdColab() {
		return idColab;
	}

	public void setIdColab(int idColab) {
		this.idColab = idColab;
	}

	public int getRacf() {
		return racf;
	}

	public void setRacf(int racf) {
		this.racf = racf;
	}

	public String getNomeColab() {
		return nomeColab;
	}

	public void setNomeColab(String nomeColab) {
		this.nomeColab = nomeColab;
	}

	public Departamento getDepartamento() {
		return departamento;
	}

	public void setDepartamento(Departamento departamento) {
		this.departamento = departamento;
	}

	public List<Historico> getHistoricos() {
		return historicos;
	}

	public void setHistoricos(List<Historico> historicos) {
		this.historicos = historicos;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public int getNumEquip() {
		return numEquip;
	}

	public void setNumEquip(int numEquip) {
		this.numEquip = numEquip;
	}

	public String getDescEquip() {
		return descEquip;
	}

	public void setDescEquip(String descEquip) {
		this.descEquip = descEquip;
	}

	public String getNumConectRede() {
		return numConectRede;
	}

	public void setNumConectRede(String numConectRede) {
		this.numConectRede = numConectRede;
	}

	public String getFoto() {
		return foto;
	}

	public void setFoto(String foto) {
		this.foto = foto;
	}


	
	
}
