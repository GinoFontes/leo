package br.com.itau.desafio.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="TBL_DESAFIO_DEPARTAMENTOS")
public class Departamento {
	
	@Column(name="IdDEPART")
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idDepart;
	
	@Column(name="NOME", length=30)
	private String nomeDepart;
	
	@Column(name="VLAN", length=50)
	private String nomeVlan;
	
	@Column(name="REDE", length=50)
	private String rede;
	
	//* Card Depart ->  (OneToMany)
	@JsonIgnoreProperties("departamento")
	@OneToMany(cascade=CascadeType.ALL , mappedBy="departamento")
	private List<Colaborador> colaboradores;
	
	//* Card Depart ->  (OneToMany)
	@JsonIgnoreProperties("departamento")
	@OneToMany(cascade=CascadeType.ALL , mappedBy="departamento")
	private List<Historico> historico;


	public int getIdDepart() {
		return idDepart;
	}

	public void setIdDepart(int idDepart) {
		this.idDepart = idDepart;
	}

	public String getNomeDepart() {
		return nomeDepart;
	}

	public void setNomeDepart(String nomeDepart) {
		this.nomeDepart = nomeDepart;
	}

	public String getNomeVlan() {
		return nomeVlan;
	}

	public void setNomeVlan(String nomeVlan) {
		this.nomeVlan = nomeVlan;
	}

	public String getRede() {
		return rede;
	}

	public void setRede(String rede) {
		this.rede = rede;
	}

	public List<Colaborador> getColaboradores() {
		return colaboradores;
	}

	public void setColaboradores(List<Colaborador> colaboradores) {
		this.colaboradores = colaboradores;
	}

	public List<Historico> getHistorico() {
		return historico;
	}

	public void setHistorico(List<Historico> historico) {
		this.historico = historico;
	}
	

	
}
